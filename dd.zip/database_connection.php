<?php
$hostname = "localhost";
$username = "root";
$password = "";  
$database = "dd_check_out";   
$con=mysqli_connect($hostname,$username,$password,$database);    
?>   