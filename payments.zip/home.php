<!-- <!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Stripe Payment Demo</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="container">
        <h1>Welcome to the Stripe Payment Demo</h1>
        <p>This is a simple example of how Stripe payment works in pure PHP.</p>
        <a href="index.php?page=checkout" class="button">Proceed to Checkout</a>
    </div>
</body>
</html> -->

<?php
session_start();
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Payment Method</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">

</head>

<body class="bg-dark">

    <div class="container">
        <div class="row text-center mt-5 justify-content-center align-items-center">

            <h1 class="text-white">Payment Method</h1>

            <?php
            if (isset($_SESSION['error'])) {  // Ensure the session variable is set
                echo '<div class="alert alert-danger">';
                echo $_SESSION['error'];      // Display the error message
                echo '</div>';
                unset($_SESSION['error']);    // Optionally clear the error after displaying
            }
            ?>



            <div class="btn-group mt-3 justify-content-center">

                <form method="POST" action="index.php?page=checkout">
                    <button type="submit" class="btn btn-primary me-2">Stripe Payment</button>
                </form>

                <form action="index2.php" method="POST">
                    <button type="submit" class="btn btn-outline-primary">Finance Payment</button>
                </form>

            </div>

        </div>
    </div>



    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous">
        </script>
</body>

</html>