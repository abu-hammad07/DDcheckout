<?php
// Include Composer's autoloader to use Stripe SDK
require 'vendor/autoload.php'; // This loads Stripe PHP SDK

// Start session to track data if needed
session_start();

// Routing Logic
if (isset($_GET['page'])) {
    if ($_GET['page'] == 'checkout') {
        checkout();
    } elseif ($_GET['page'] == 'success') {
        success();
    } else {
        index();
    }
} else {
    index();
}

function index()
{
    // Redirect to the home.php page
    header("Location: home.php");
    exit;
}


// Function to handle the Stripe Checkout session
function checkout()
{
    // Set your Stripe Secret Key
    \Stripe\Stripe::setApiKey('sk_test_51Q7hfYH4t5vduQNBWYZf8F9DMQqMR5f9T9oHjHfeaE6m8OfRB1DWARDZA54RQ3ibm6Mhaq2GPOFxNf7SGE0CvCLK00A0lToz38'); // Replace with your actual secret key from Stripe

    try {
        // Create a Stripe Checkout session
        $session = \Stripe\Checkout\Session::create([
            'line_items' => [
                [
                    'price_data' => [
                        'currency' => 'gbp', // Set the currency
                        'product_data' => [
                            'name' => 'Send me money!!!', // Name of the product
                        ],
                        'unit_amount' => 500, // £5.00 (amount is in pence)
                    ],
                    'quantity' => 1,
                ],
            ],
            'mode' => 'payment',
            'success_url' => 'http://localhost/stripe_finance_payments/index.php?page=success', // Success URL after payment
            'cancel_url' => 'http://localhost/stripe_finance_payments/index.php', // Cancel URL if the payment fails
        ]);

        // Redirect the user to the Stripe Checkout page
        header("Location: " . $session->url);
        exit;

    } catch (Exception $e) {
        // Handle any errors
        echo 'Error creating checkout session: ' . $e->getMessage();
    }
}

// Function to display the success page
function success()
{
    echo '<h1>Payment Successful!</h1>';
    echo '<p>Thank you for your payment.</p>';
    echo '<a href="index.php">Back to Home</a>';
}
